// 개인정보 masking
const email = "codecamp@gmail.com"
//1. @ 확인하여 email 인지 판단
//2. @기준으로 앞과 뒤 분리
//3. masking 
//4. 합친다
email.includes("@")
// true
email.split("@")
email.split("@")[0]
//codecamp
email.split("@")[1]
//gmail.com
let userMail = email.split("@")[0]
let company = email.split("@")[1]

let maskingMail = []
maskingMail.push(userMail[0])
maskingMail.push(userMail[1])
maskingMail.push(userMail[2])
maskingMail.push(userMail[3])
// ['c','o', 'd','e']
maskingMail.push("*")
maskingMail.push("*")
maskingMail.push("*")
maskingMail.push("*")
console.log(maskingMail)
// ['c', 'o', 'd', 'e', '*', '*', '*', '*']
let result = maskingMail.join("/")
console.log(result)
//c/o/d/e/*/*/*/*
result = maskingMail.join("")
console.log(result)
// code****
result = maskingMail.join("") + "@" + company
console.log(result)
//code****@gmail.com