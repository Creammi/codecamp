function greeting() {

    document.getElementById("target").innerText ="World"
    document.getElementById("input").value ="World"

}