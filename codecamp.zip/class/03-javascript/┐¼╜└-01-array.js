// 1. 상수와 변수
let vName
const cName ="최민준"

vName = "서지심"

console.log(vName)
console.log(cName)
// 2. 배열
let name1="길동"
let name2="철수"
let name3="영희"
let name4="준석"

let students = ["길동","철수","영희","준석"]
// index           0      1     2      3
// length          1      2     3      4
console.log(students[0])

// let array=[]
// let numArr=[99,105,3,72,6]
let array=["문자열","배열","만들기"]

//  array.length   :배열의길이              
//  array[숫자(인덱스)]    :배열의값꺼내기          
//  array.push()   :배열맨 뒤에 값추가      
//  array.pop()    :배열맨 마지막 값 삭제
//  array.sort()   :배열요소정렬            
//  array.includes(값) :배열 데이터 확인        
//  array.concat(array2)    :배열 2개 연결
//  array.join()    :배열을 문자로 만들기
//  array.slice()   :배열분리
//  array.filter()  :배열에서 원하는 요소 뽑기
//  array.map()     :배열의 모든요소변경

let classMate = ["철수" , "영희" , "훈이"]
//undefined
classMate
//(3) ['철수', '영희', '훈이']
classMate[0]
//'철수'
classMate[1]
//'영희'
classMate[2]
//'훈이'
classMate.includes("훈이")
//true
classMate.includes("맹구")
//false
classMate.length
//3
classMate.push("맹구")
//4
classMate.includes("맹구")
//true
classMate.length
//4
classMate.pop()
//'맹구'
classMate.length
//3
classMate
//(3) ['철수', '영희', '훈이']

let developer = ["워라벨","연봉","신분상승","커리어점프","명성"]
console.log(developer[1])

let dream = ["커리어점프","성공","할수있다"]

let result = developer.concat(dream)

console.log(result)
