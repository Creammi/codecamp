let persons = [
    {name: "철수", age:17},
    {name:"영희", age:22},
    {name:"도우너",age:5},
    {name:"그루트",age:65},
    {name:"되",age:3}]
//undefine

for (let count = 0;count < persons.length; count ++){
    if (persons[count].age >= 19){
        console.log ("성인입니다")
    } else {
        console.log("미성년자입니다 ")
    }
}
// 미성년자입니다 
// VM903:3 성인입니다
// VM903:5 미성년자입니다 
// VM903:3 성인입니다
// VM903:5 미성년자입니다 


for (let count = 0;count < persons.length; count ++){
    if (persons[count].age >= 19){
        console.log( persons[count].name+"님은 성인입니다")
    } else {
        console.log( persons[count].name+"님은 미성년자입니다")
    }
}
// 철수님은 미성년자입니다
// VM915:3 영희님은 성인입니다
// VM915:5 도우너님은 미성년자입니다
// VM915:3 그루트님은 성인입니다
// VM915:5 되님은 미성년자입니다


const fruits = [
    {number : 1 , title: "레드향"},
    {number : 2 , title: "샤인머스켓"},
    {number : 3 , title: "산청딸기"},
    {number : 4 , title: "한라봉"},
    {number : 5 , title: "사과"},
    {number : 6 , title: "애플망고"},
    {number : 7 , title: "딸기"},
    {number : 8 , title: "천혜향"},
    {number : 9 , title: "과일선물세트"},
    {number : 10 , title: "귤"},
   ];
   
   for (let index=0 ; index <10 ; index ++ )
   {
      console.log( fruits[index].number + " " + fruits[index].title)
   }

// 1 레드향
// 2 샤인머스켓
// 3 산청딸기
// 4 한라봉
// 5 사과
// 6 애플망고
// 7 딸기
// 8 천혜향
// 9 과일선물세트
// V10 귤
for (let index=0 ; index <10 ; index ++ )
{
   console.log( `${fruits[index].number}  ${fruits[index].title}`)
}
// ` (back tic ) 을 쓰면 문자열을 + " " + 을 안써도 된다 . 똑 같이 나온다
 
// 1 레드향
// 2 샤인머스켓
// 3 산청딸기
// 4 한라봉
// 5 사과
// 6 애플망고
// 7 딸기
// 8 천혜향
// 9 과일선물세트
// 10 귤


for (let index=0 ; index <10 ; index ++ )
{
   console.log( `과일차트 ${fruits[index].number}위는  ${fruits[index].title}입니다.`)
}

// 과일차트 1위는  레드향입니다.
// 과일차트 2위는  샤인머스켓입니다.
// 과일차트 3위는  산청딸기입니다.
// 과일차트 4위는  한라봉입니다.
// 과일차트 5위는  사과입니다.
// 과일차트 6위는  애플망고입니다.
// 과일차트 7위는  딸기입니다.
// 과일차트 8위는  천혜향입니다.
// 과일차트 9위는  과일선물세트입니다.
// 과일차트 10위는  귤입니다.

//인증번호 만들기 
Math.floor(Math.random() * 1000000)
222684
String(Math.floor(Math.random() * 1000000))
'920996'
String(Math.floor(Math.random() * 1000000))
'241077'
String(Math.floor(Math.random() * 1000000))
'502443'
String(Math.floor(Math.random() * 1000000))
'957358'
String(Math.floor(Math.random() * 1000000))
'961564'
String(Math.floor(Math.random() * 1000000))
'699298'
String(Math.floor(Math.random() * 1000000))
'34389'
String(Math.floor(Math.random() * 1000000))
'31380'
String(Math.floor(Math.random() * 1000000)).padStart(6,"0")
'800219'
String(Math.floor(Math.random() * 1000000)).padStart(6,"0")
'895876'
let result = String(Math.floor(Math.random() * 1000000)).padStart(6,"0")
